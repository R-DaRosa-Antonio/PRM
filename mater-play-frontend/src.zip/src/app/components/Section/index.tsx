import {Box, Container, Stack, Typography } from "@mui/material";
import Moviecard from "../MovieCard";

const movies =[
    {poster:'house-of-dragons-poster.jpg'},
    {poster:'2zmTngn1tYC1AvfnrFLhxeD82hz.jpg'},
    {poster:'9h2KgGXSmWigNTn3kQdEFFngj9i.jpg'},
    {poster:'xeeF1KWSz8EEUl8RBz64qRnxm7V.jpg'},
    
    {poster:'house-of-dragons-poster.jpg'},
    {poster:'2zmTngn1tYC1AvfnrFLhxeD82hz.jpg'},
    {poster:'9h2KgGXSmWigNTn3kQdEFFngj9i.jpg'},
    {poster:'xeeF1KWSz8EEUl8RBz64qRnxm7V.jpg'},
    
    {poster:'house-of-dragons-poster.jpg'},
    {poster:'2zmTngn1tYC1AvfnrFLhxeD82hz.jpg'},
    {poster:'9h2KgGXSmWigNTn3kQdEFFngj9i.jpg'},
    {poster:'xeeF1KWSz8EEUl8RBz64qRnxm7V.jpg'}

];

function Section(){
    return(
        <Box>
          <Container>
            <Typography
                variant="h6"
            >
                Para Toda Família

            </Typography>
            <Stack
                direction="row"
                gap="5rem"
                sx={{
                    overflowY=""
                }}
            >
                {movies.map(item=>(
                    <Moviecard poster={'assets/'+ item.poster}/>
                ))}
                

            </Stack>

            </Container>  
        </Box>
    )
}

export default Section;